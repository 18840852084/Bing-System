package com.ourq20.model;

public class requestAddCount {
	private String name;
	private int answer;
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public int getAnswer()
	{
		return answer;
	}
	public void setAnswer(int answer)
	{
		this.answer=answer;
	}
}
