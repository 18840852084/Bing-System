package com.ourq20.model;

import java.util.Date;

public class birthInfoOfPerson {
	private String name;
	private Date dateOfBorn;
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public Date getDateofBorn()
	{
		return dateOfBorn;
	}
	public void setDateofBorn(Date dateofBorn)
	{
		this.dateOfBorn=dateofBorn;
	}
}
