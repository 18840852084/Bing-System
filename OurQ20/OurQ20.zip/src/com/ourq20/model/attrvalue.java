package com.ourq20.model;
public class attrvalue {
	private String value;
	private int attrID;
	public String getValue()
	{
		return value;
	}
	public void setValue(String value)
	{
		this.value=value;
	}
	public int getAttrID()
	{
		return attrID;
	}
	public void setAttrID(int attrID)
	{
		this.attrID=attrID;
	}

}
