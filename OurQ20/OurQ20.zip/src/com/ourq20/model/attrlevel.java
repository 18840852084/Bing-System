package com.ourq20.model;

public class attrlevel {
	private int attrID;
	private String attrName;
	private int attrLevel;
	public int getAttrID()
	{
		return attrID;
	}
	public void setAtrrID(int attrID)
	{
		this.attrID=attrID;
	}
	public String getAttrName()
	{
		return attrName;
	}
	public void setAttrName(String attrName)
	{
		this.attrName=attrName;
	}
	public int getAttrLevel()
	{
		return attrLevel;
	}
	public void setAttrLevel(int attrLevel)
	{
		this.attrLevel=attrLevel;
	}

}
