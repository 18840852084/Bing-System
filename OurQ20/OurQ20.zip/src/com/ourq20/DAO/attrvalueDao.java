package com.ourq20.DAO;

import java.util.List;

public interface attrvalueDao {
	public List<String>getAttrValueById(int attrID);

}
