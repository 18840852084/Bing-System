package com.ourq20.DAO;

import java.util.List;

import com.ourq20.model.attrlevel;

public interface attrlevelDao {
	public List<attrlevel> getArrLevelByLevel(int attrLevel);

}
